package lib;
/*
 * ***@author qiaoxi li
 */
public class NoToBeCoupledException extends Exception{
	   public NoToBeCoupledException()
	   {
	   	super("TOO YOUNG !!!");
	   }
	}
