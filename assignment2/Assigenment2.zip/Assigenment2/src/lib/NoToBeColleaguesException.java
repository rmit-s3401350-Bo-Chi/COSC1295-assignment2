package lib;
/*
 * ***@author qiaoxi li
 */
public class NoToBeColleaguesException  extends Exception{
	   public NoToBeColleaguesException()
	   {
	   	super("TOO YOUNG TO BE CLASSMATE!!!");
	   }
	

}
