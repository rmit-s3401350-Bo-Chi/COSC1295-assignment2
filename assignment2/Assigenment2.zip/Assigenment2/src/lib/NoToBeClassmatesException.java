package lib;
/*
 * ***@author qiaoxi li
 */
public class NoToBeClassmatesException extends Exception{
   public NoToBeClassmatesException()
   {
   	super("TOO YOUNG CANNOT BE CLASSMATE!!!");
   }
}
