package lib;
/*
 * ***@author qiaoxi li
 */
import javax.swing.JOptionPane;

public class NoSuchAgeException extends Exception{
	public NoSuchAgeException()
	{
		JOptionPane.showMessageDialog(null, "NoSuchAgeException���r(�s���t)�q"); 
    }

}
