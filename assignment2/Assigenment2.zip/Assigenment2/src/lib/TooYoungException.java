package lib;
/*
 * ***@author qiaoxi li
 */
public class TooYoungException extends Exception {
	public TooYoungException()  {
	   	super("CANNOT MAKE THEM FRIENDS !!!");
	   }
	}
