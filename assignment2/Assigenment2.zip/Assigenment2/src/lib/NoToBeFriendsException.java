package lib;
/*
 * ***@author qiaoxi li
 */
public class NoToBeFriendsException extends Exception{
	   public NoToBeFriendsException()
	   {
	   	super("CANNOT MAKE THEM FRIENDS !!!");
	   }
	}