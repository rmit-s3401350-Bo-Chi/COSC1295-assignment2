package lib;
/*
 * ***@author qiaoxi li
 */

public class NoAvailableException extends Exception {
    public NoAvailableException()
    {
    	super("someone spouse whit someone but you dont know!!!");
    }
}
